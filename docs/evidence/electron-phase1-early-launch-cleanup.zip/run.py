import subprocess,sys,json,datetime,pathlib,os
name,*cmd=sys.argv[1:]
root=pathlib.Path('/workspace/work/early-launch')
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/'logs'/f'{name}.log').open('w') as f:
    result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
record={'command':cmd,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode}
(root/'logs'/f'{name}.command.json').write_text(json.dumps(record,indent=2)+'\n')
print(name, 'exit',result.returncode)
print('\n'.join((root/'logs'/f'{name}.log').read_text().splitlines()[-15:]))
sys.exit(result.returncode)
