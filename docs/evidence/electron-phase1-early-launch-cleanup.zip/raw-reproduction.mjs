import { _electron } from '/workspace/siaas-personal/node_modules/playwright/index.mjs';
import { runTest } from '/workspace/siaas-personal/tests/helpers/runtime.mjs';
await runTest('unpatched-launch-reproduction', async run => {
  const profile = await run.tempDir();
  console.log('FIXTURE:' + JSON.stringify({out:run.out,profile}));
  await _electron.launch({executablePath:process.execPath,chromiumSandbox:true,args:['--user-data-dir='+profile],timeout:5000});
}, {mode:'negative-control/unpatched-playwright/no-native-electron'});
