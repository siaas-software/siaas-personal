import subprocess,os,json,pathlib
commands=[['cat','/etc/os-release'],['uname','-srmo'],['id'],['node','--version'],['npm','--version'],['sh','-c','command -v Xvfb xvfb-run Xorg xauth xdpyinfo unshare'],['sh','-c',"rg '^(NoNewPrivs|Seccomp|CapEff):' /proc/self/status"],['cat','/proc/sys/user/max_user_namespaces'],['unshare','-Ur','true'],['dpkg-query','-W','libnss3','libgtk-3-0t64','libgbm1','libasound2t64','libatk1.0-0t64','libx11-6','libxcomposite1','libxdamage1','libxrandr2','libxkbcommon0','xauth','xvfb']]
for cmd in commands:
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    print('COMMAND',json.dumps(cmd),'EXIT',p.returncode,flush=True)
    print(p.stdout,flush=True)
print('Display selectors:',json.dumps({k:os.environ.get(k) for k in ['DISPLAY','WAYLAND_DISPLAY']}))
p=pathlib.Path('node_modules/electron/path.txt')
print('Electron path.txt exists:',p.exists())
print('Xorg dummy driver exists:',pathlib.Path('/usr/lib/xorg/modules/drivers/dummy_drv.so').exists())
