import subprocess,os,secrets,time,json,pathlib
root=pathlib.Path('/workspace/work/native-linux')
auth=root/'xauthority'
auth.touch(mode=0o600)
subprocess.run(['xauth','-f',str(auth),'add',':91','.',secrets.token_hex(16)],check=True)
env={**os.environ,'DISPLAY':':91','XAUTHORITY':str(auth)}
cmd=['Xorg',':91','-config',str(root/'xorg.conf'),'-logfile',str(root/'logs/xorg-server.log'),'-auth',str(auth),'-nolisten','tcp','-noreset']
record={'command':cmd}
try:
 with (root/'logs/xorg-console.log').open('w') as log:
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
  record['pid']=child.pid
  ready=False
  for _ in range(20):
   probe=subprocess.run(['xdpyinfo'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   if probe.returncode==0:
    ready=True
    break
   if child.poll() is not None: break
   time.sleep(.25)
  (root/'logs/xdpyinfo.log').write_text(probe.stdout)
  record['display_ready']=ready
  if ready:
   result=subprocess.run(['python3',str(root/'run.py'),'desktop-smoke','npm','run','test:desktop:smoke'],env=env)
   record['smoke_exit']=result.returncode
finally:
 if 'child' in locals():
  if child.poll() is None:
   child.terminate()
   try: child.wait(timeout=5)
   except subprocess.TimeoutExpired: child.kill(); child.wait()
  record['xorg_exit']=child.returncode
  record['xorg_reaped']=True
 auth.unlink(missing_ok=True)
 record['auth_removed']=not auth.exists()
 (root/'logs/display-attempt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2))
